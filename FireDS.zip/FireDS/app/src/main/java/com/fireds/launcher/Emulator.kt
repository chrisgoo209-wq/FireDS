package com.fireds.launcher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import java.io.File

/** Hands a ROM to RetroArch (running the DeSmuME libretro core) using RetroArch's launch-intent extras. */
object Emulator {

    fun isInstalled(ctx: Context, pkg: String): Boolean = try {
        ctx.packageManager.getPackageInfo(pkg, 0); true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }

    /** Returns an error message to show the user, or null on success. */
    fun launch(ctx: Context, prefs: Prefs, game: Game): String? {
        if (prefs.backend == Backend.DRASTIC) return launchDrastic(ctx, prefs, game)
        val pkg = prefs.retroPackage
        if (!isInstalled(ctx, pkg)) return "RetroArch ($pkg) isn't installed. Pick the right one in Settings."

        val opts = prefs.gameOpts(game.path)
        val cfgPath = try {
            writeConfigs(ctx, pkg, prefs.core, game, opts)
        } catch (e: Exception) {
            return "Couldn't write the game config: ${e.message}"
        }

        val intent = Intent().apply {
            component = ComponentName(pkg, "com.retroarch.browser.retroactivity.RetroActivityFuture")
            putExtra("ROM", game.path)
            putExtra("LIBRETRO", "/data/data/$pkg/cores/${prefs.core}")
            putExtra("CONFIGPATH", cfgPath)
            putExtra("IME", "com.android.inputmethod.latin/.LatinIME")
            putExtra("DATADIR", "/data/data/$pkg")
            putExtra("APK", "/data/app/$pkg-1/base.apk")
            putExtra("SDCARD", "/storage/emulated/0")
            putExtra("DOWNLOADS", "/storage/emulated/0/Download")
            putExtra("SCREENSHOTS", "/storage/emulated/0/Pictures")
            putExtra("BUGREPORT", "/storage/emulated/0")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        return try {
            prefs.markPlayed(game.path)
            ctx.startActivity(intent)
            null
        } catch (e: Exception) {
            "Couldn't start RetroArch: ${e.message}"
        }
    }

    /**
     * Opens the ROM straight in DraStic with a standard "open with" intent, so DraStic's own
     * mouse-driven file browser is skipped. DraStic is closed source; this is the same intent other
     * frontends use, but it is untested on your stick.
     */
    private fun launchDrastic(ctx: Context, prefs: Prefs, game: Game): String? {
        if (!isInstalled(ctx, DRASTIC_PACKAGE)) return "DraStic isn't installed on this device."
        val intent = Intent(Intent.ACTION_VIEW).apply {
            component = ComponentName(DRASTIC_PACKAGE, "$DRASTIC_PACKAGE.DraSticActivity")
            data = Uri.fromFile(File(game.path))
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        return try {
            prefs.markPlayed(game.path)
            ctx.startActivity(intent)
            null
        } catch (e: Exception) {
            "Couldn't start DraStic: ${e.message}"
        }
    }

    /**
     * Builds a per-game copy of RetroArch's own retroarch.cfg with the performance preset applied,
     * plus a per-game core options file. Returns the cfg path to pass as CONFIGPATH.
     * Starting from the user's real retroarch.cfg keeps their controller bindings and folders.
     */
    private fun writeConfigs(ctx: Context, pkg: String, core: String, game: Game, opts: GameOpts): String {
        val dir = ctx.getExternalFilesDir("config") ?: ctx.filesDir
        dir.mkdirs()
        val id = game.path.hashCode().toUInt().toString(16)

        val cfg = linkedMapOf<String, String>()
        val base = File("/storage/emulated/0/Android/data/$pkg/files/retroarch.cfg")
        if (base.canRead()) {
            base.forEachLine { line ->
                val i = line.indexOf('=')
                if (i > 0) cfg[line.substring(0, i).trim()] = line.substring(i + 1).trim().trim('"')
            }
        }

        when (opts.preset) {
            Preset.FAST -> {
                cfg["video_threaded"] = "true"; cfg["video_smooth"] = "false"; cfg["audio_latency"] = "128"
            }
            Preset.BALANCED -> {
                cfg["video_threaded"] = "true"; cfg["video_smooth"] = "false"; cfg["audio_latency"] = "96"
            }
            Preset.QUALITY -> {
                cfg["video_threaded"] = "false"; cfg["video_smooth"] = "true"; cfg["audio_latency"] = "64"
            }
        }

        // Core options (names are for the desmume core; other cores just ignore unknown keys).
        val optsFile = File(dir, "$id.opt")
        val coreOpts = linkedMapOf(
            "desmume_screens_layout" to opts.layout.coreValue,
            "desmume_internal_resolution" to if (opts.preset == Preset.QUALITY) "512x384" else "256x192",
            "desmume_frameskip" to if (opts.preset == Preset.FAST) "2" else "0"
        )
        optsFile.writeText(coreOpts.entries.joinToString("\n") { "${it.key} = \"${it.value}\"" } + "\n")
        cfg["global_core_options"] = "true"
        cfg["core_options_path"] = optsFile.absolutePath

        val cfgFile = File(dir, "$id.cfg")
        cfgFile.writeText(cfg.entries.joinToString("\n") { "${it.key} = \"${it.value}\"" } + "\n")
        return cfgFile.absolutePath
    }
}
