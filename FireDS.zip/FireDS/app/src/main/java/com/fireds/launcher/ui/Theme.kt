package com.fireds.launcher.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEvent
import androidx.compose.ui.input.key.key

object Pal {
    val bg = Color(0xFF0B0D14)
    val panel = Color(0xFF161A26)
    val text = Color(0xFFF2F4FA)
    val dim = Color(0xFF8B93A8)
    val accent = Color(0xFF3DDCFF)
}

@Composable
fun FireDsTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(primary = Pal.accent, background = Pal.bg, surface = Pal.panel),
        content = content
    )
}

fun KeyEvent.isSelect() = key == Key.DirectionCenter || key == Key.Enter || key == Key.NumPadEnter || key == Key.ButtonA
fun KeyEvent.isMenu() = key == Key.Menu || key == Key.ButtonY || key == Key.ButtonX
fun KeyEvent.isBackKey() = key == Key.Back || key == Key.ButtonB || key == Key.Escape
