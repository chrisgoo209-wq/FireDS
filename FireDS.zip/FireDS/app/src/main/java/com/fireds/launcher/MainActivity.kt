package com.fireds.launcher

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.fireds.launcher.ui.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Lets us hand DraStic a plain file:// path (blocked by default on newer targetSdk).
        android.os.StrictMode.setVmPolicy(android.os.StrictMode.VmPolicy.Builder().build())
        val prefs = Prefs(this)
        setContent { FireDsTheme { App(prefs) } }
    }
}

private fun <T> List<T>.cycle(current: T, dir: Int): T {
    val i = indexOf(current).let { if (it < 0) 0 else it }
    return this[(i + dir + size) % size]
}

@Composable
private fun App(prefs: Prefs) {
    val ctx = LocalContext.current

    fun permOk(c: Context) =
        ContextCompat.checkSelfPermission(c, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    var games by remember { mutableStateOf<List<Game>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var scanKey by remember { mutableStateOf(0) }
    var hasPerm by remember { mutableStateOf(permOk(ctx)) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        hasPerm = it
        scanKey++
    }
    LaunchedEffect(Unit) { if (!hasPerm) permLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE) }

    LaunchedEffect(scanKey, hasPerm) {
        loading = true
        games = if (hasPerm) withContext(Dispatchers.IO) { RomScanner.scan(prefs) } else emptyList()
        loading = false
    }

    var showSettings by remember { mutableStateOf(false) }
    var optionsFor by remember { mutableStateOf<Game?>(null) }
    var optsTick by remember { mutableStateOf(0) } // bumps when any per-game setting changes

    fun play(g: Game) {
        Emulator.launch(ctx, prefs, g)?.let { Toast.makeText(ctx, it, Toast.LENGTH_LONG).show() }
    }

    Box(Modifier.fillMaxSize()) {
        HomeScreen(
            games = games,
            loading = loading,
            permissionOk = hasPerm,
            infoFor = {
                optsTick
                if (prefs.backend == Backend.DRASTIC) "DraStic"
                else prefs.gameOpts(it.path).let { o -> "${o.preset.label}  ·  ${o.layout.label}" }
            },
            active = !showSettings && optionsFor == null,
            onPlay = ::play,
            onOptions = { optionsFor = it },
            onSettings = { showSettings = true }
        )

        optionsFor?.let { g ->
            var o by remember(g.path) { mutableStateOf(prefs.gameOpts(g.path)) }
            fun update(n: GameOpts) { o = n; prefs.saveGameOpts(g.path, n); optsTick++ }
            Panel(
                title = g.title,
                rows = buildList {
                    add(PanelRow("Play", onSelect = { optionsFor = null; play(g) }))
                    // Performance and layout are RetroArch-only; DraStic keeps its own settings.
                    if (prefs.backend == Backend.RETROARCH) {
                        add(PanelRow("Performance", o.preset.label,
                            onChange = { update(o.copy(preset = Preset.values().toList().cycle(o.preset, it))) }))
                        add(PanelRow("Screen layout", o.layout.label,
                            onChange = { update(o.copy(layout = Layout.values().toList().cycle(o.layout, it))) }))
                    }
                },
                onClose = { optionsFor = null }
            )
        }

        if (showSettings) {
            var tick by remember { mutableStateOf(0) } // forces the rows to redraw after a change
            val drastic = prefs.backend == Backend.DRASTIC
            val installed = Emulator.isInstalled(ctx, if (drastic) DRASTIC_PACKAGE else prefs.retroPackage)
            Panel(
                title = "Settings",
                rows = buildList {
                    tick
                    add(PanelRow("Emulator", prefs.backend.label + if (installed) "" else "  (not installed)",
                        onChange = { prefs.backend = Backend.values().toList().cycle(prefs.backend, it); tick++; optsTick++ }))
                    if (!drastic) {
                        add(PanelRow("RetroArch app", prefs.retroPackage,
                            onChange = { prefs.retroPackage = RETROARCH_PACKAGES.cycle(prefs.retroPackage, it); tick++ }))
                        add(PanelRow("RetroArch core", prefs.core.removeSuffix("_libretro_android.so"),
                            onChange = { prefs.core = CORES.cycle(prefs.core, it); tick++ }))
                        add(PanelRow("Default performance", prefs.defaultPreset.label,
                            onChange = { prefs.defaultPreset = Preset.values().toList().cycle(prefs.defaultPreset, it); tick++; optsTick++ }))
                    }
                    add(PanelRow("Allow storage access", if (hasPerm) "On" else "Off",
                        onSelect = { permLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE) }))
                    add(PanelRow("Rescan games", "${games.size} found",
                        onSelect = { scanKey++; showSettings = false }))
                },
                onClose = { showSettings = false }
            )
        }
    }
}
