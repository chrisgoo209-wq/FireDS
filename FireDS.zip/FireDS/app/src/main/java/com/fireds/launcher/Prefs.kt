package com.fireds.launcher

import android.content.Context

enum class Preset(val label: String) {
    FAST("Fast"), BALANCED("Balanced"), QUALITY("Quality")
}

enum class Layout(val label: String, val coreValue: String) {
    TOP_BOTTOM("Top / Bottom", "top/bottom"),
    LEFT_RIGHT("Side by side", "left/right"),
    HYBRID("Big top + small bottom", "hybrid/top"),
    TOP_ONLY("Top only", "top only"),
    BOTTOM_ONLY("Bottom only", "bottom only")
}

enum class Backend(val label: String) {
    DRASTIC("DraStic"), RETROARCH("RetroArch")
}

const val DRASTIC_PACKAGE = "com.dsemu.drastic"

val RETROARCH_PACKAGES = listOf("com.retroarch", "com.retroarch.aarch64", "com.retroarch.ra32")
val CORES = listOf(
    "desmume_libretro_android.so",
    "desmume2015_libretro_android.so",
    "melonds_libretro_android.so"
)

data class GameOpts(val preset: Preset, val layout: Layout)

/** Small SharedPreferences wrapper. Everything the launcher remembers lives here. */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("fireds", Context.MODE_PRIVATE)

    var backend: Backend
        get() = Backend.valueOf(sp.getString("backend", Backend.DRASTIC.name)!!)
        set(v) = sp.edit().putString("backend", v.name).apply()

    var retroPackage: String
        get() = sp.getString("pkg", RETROARCH_PACKAGES[0])!!
        set(v) = sp.edit().putString("pkg", v).apply()

    var core: String
        get() = sp.getString("core", CORES[0])!!
        set(v) = sp.edit().putString("core", v).apply()

    var defaultPreset: Preset
        get() = Preset.valueOf(sp.getString("defPreset", Preset.BALANCED.name)!!)
        set(v) = sp.edit().putString("defPreset", v.name).apply()

    fun gameOpts(path: String) = GameOpts(
        preset = sp.getString("preset:$path", null)?.let { Preset.valueOf(it) } ?: defaultPreset,
        layout = sp.getString("layout:$path", null)?.let { Layout.valueOf(it) } ?: Layout.TOP_BOTTOM
    )

    fun saveGameOpts(path: String, o: GameOpts) = sp.edit()
        .putString("preset:$path", o.preset.name)
        .putString("layout:$path", o.layout.name).apply()

    fun lastPlayed(path: String) = sp.getLong("last:$path", 0L)
    fun markPlayed(path: String) = sp.edit().putLong("last:$path", System.currentTimeMillis()).apply()
}
