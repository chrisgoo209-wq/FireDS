package com.fireds.launcher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** One line in a menu. [onChange] gets -1 / +1 for left / right; [onSelect] fires on OK / A. */
data class PanelRow(
    val label: String,
    val value: String? = null,
    val onChange: ((Int) -> Unit)? = null,
    val onSelect: (() -> Unit)? = null
)

/** Full-screen dimmed overlay holding a centered, D-pad driven menu card. */
@Composable
fun Panel(title: String, rows: List<PanelRow>, onClose: () -> Unit) {
    var sel by remember { mutableStateOf(0) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }
    BackHandler(onBack = onClose)

    Box(
        Modifier.fillMaxSize().background(Color(0xCC000000)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .width(620.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Pal.panel)
                .padding(32.dp)
                .focusRequester(focus)
                .focusable()
                .onPreviewKeyEvent { e ->
                    if (e.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                    val row = rows.getOrNull(sel)
                    when {
                        e.key == Key.DirectionDown -> { sel = (sel + 1).coerceAtMost(rows.lastIndex); true }
                        e.key == Key.DirectionUp -> { sel = (sel - 1).coerceAtLeast(0); true }
                        e.key == Key.DirectionLeft -> { row?.onChange?.invoke(-1); true }
                        e.key == Key.DirectionRight -> { row?.onChange?.invoke(1); true }
                        e.isSelect() -> {
                            if (row?.onSelect != null) row.onSelect.invoke() else row?.onChange?.invoke(1)
                            true
                        }
                        e.isBackKey() -> { onClose(); true }
                        else -> false
                    }
                }
        ) {
            Text(title, color = Pal.text, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(20.dp))
            rows.forEachIndexed { i, r ->
                val focused = i == sel
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (focused) Pal.accent.copy(alpha = 0.18f) else Color.Transparent)
                        .padding(horizontal = 18.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        r.label,
                        color = if (focused) Pal.text else Pal.dim,
                        fontSize = 22.sp,
                        fontWeight = if (focused) FontWeight.SemiBold else FontWeight.Normal,
                        modifier = Modifier.weight(1f)
                    )
                    if (r.value != null) {
                        val arrows = focused && r.onChange != null
                        Text(
                            (if (arrows) "◂  " else "") + r.value + (if (arrows) "  ▸" else ""),
                            color = if (focused) Pal.accent else Pal.dim,
                            fontSize = 22.sp
                        )
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Text("▲▼ Move    ◀▶ Change    OK Select    Back Close", color = Pal.dim, fontSize = 16.sp)
        }
    }
}
