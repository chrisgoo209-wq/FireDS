package com.fireds.launcher.ui

import android.graphics.BitmapFactory
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.key.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fireds.launcher.Game
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

private val TILE_W = 220.dp
private val TILE_H = 200.dp

private fun tintFor(title: String): Color {
    val hue = (abs(title.hashCode()) % 360).toFloat()
    return Color.hsv(hue, 0.55f, 0.70f)
}

@Composable
fun HomeScreen(
    games: List<Game>,
    loading: Boolean,
    permissionOk: Boolean,
    infoFor: (Game) -> String,
    active: Boolean,
    onPlay: (Game) -> Unit,
    onOptions: (Game) -> Unit,
    onSettings: () -> Unit
) {
    // Last tile in the row is always "Settings".
    val count = games.size + 1
    var index by rememberSaveable { mutableStateOf(0) }
    val idx = index.coerceIn(0, count - 1)
    val game = games.getOrNull(idx)

    val focus = remember { FocusRequester() }
    LaunchedEffect(active) { if (active) focus.requestFocus() }

    val tint by animateColorAsState(
        if (game != null) tintFor(game.title) else Pal.accent, tween(450), label = "tint"
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(tint.copy(alpha = 0.32f), Pal.bg, Pal.bg)))
            .focusRequester(focus)
            .focusable()
            .onPreviewKeyEvent { e ->
                if (!active || e.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                when {
                    e.key == Key.DirectionRight -> { index = (idx + 1).coerceAtMost(count - 1); true }
                    e.key == Key.DirectionLeft -> { index = (idx - 1).coerceAtLeast(0); true }
                    e.isSelect() -> { if (game != null) onPlay(game) else onSettings(); true }
                    e.isMenu() -> { if (game != null) onOptions(game) else onSettings(); true }
                    else -> false
                }
            }
    ) {
        // ---- Top bar ----
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 64.dp, vertical = 36.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("FIRE", color = Pal.text, fontSize = 30.sp, fontWeight = FontWeight.Black)
            Text("DS", color = Pal.accent, fontSize = 30.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.weight(1f))
            Clock()
        }

        // ---- Carousel ----
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val sidePad = (maxWidth - TILE_W) / 2
            val listState = rememberLazyListState()
            LaunchedEffect(idx) { listState.animateScrollToItem(idx) }

            LazyRow(
                state = listState,
                contentPadding = PaddingValues(horizontal = sidePad),
                horizontalArrangement = Arrangement.spacedBy(32.dp),
                modifier = Modifier.align(Alignment.Center).offset(y = (-30).dp).height(TILE_H + 60.dp)
            ) {
                items(count) { i ->
                    Box(Modifier.height(TILE_H + 60.dp), contentAlignment = Alignment.Center) {
                        Tile(games.getOrNull(i), focused = i == idx)
                    }
                }
            }
        }

        // ---- Info area ----
        Column(
            Modifier.align(Alignment.BottomStart).padding(start = 64.dp, bottom = 90.dp, end = 64.dp)
        ) {
            when {
                game != null -> {
                    Text(game.title, color = Pal.text, fontSize = 40.sp, fontWeight = FontWeight.Bold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(6.dp))
                    Text("Nintendo DS  ·  ${game.sizeMb} MB  ·  ${infoFor(game)}",
                        color = Pal.dim, fontSize = 20.sp)
                }
                else -> {
                    Text("Settings", color = Pal.text, fontSize = 40.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        when {
                            loading -> "Looking for games…"
                            !permissionOk -> "Storage access is off, so no games can be found. Allow it, then rescan."
                            games.isEmpty() -> "No .nds games found. Put them on a USB drive or in Downloads, then rescan."
                            else -> "RetroArch, core and default performance"
                        },
                        color = Pal.dim, fontSize = 20.sp
                    )
                }
            }
        }

        // ---- Hint bar ----
        Row(
            Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(horizontal = 64.dp, vertical = 28.dp),
            horizontalArrangement = Arrangement.spacedBy(36.dp)
        ) {
            Hint("OK / A", if (game != null) "Play" else "Open")
            Hint("☰ / Y", "Options")
            Hint("◀ ▶", "Browse")
        }
    }
}

@Composable
private fun Hint(key: String, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            key, color = Pal.bg, fontSize = 15.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.clip(RoundedCornerShape(50)).background(Pal.dim).padding(horizontal = 12.dp, vertical = 4.dp)
        )
        Spacer(Modifier.width(10.dp))
        Text(label, color = Pal.dim, fontSize = 18.sp)
    }
}

@Composable
private fun Clock() {
    val time by produceState("") {
        val fmt = SimpleDateFormat("h:mm a", Locale.getDefault())
        while (true) { value = fmt.format(Date()); delay(20_000) }
    }
    Text(time, color = Pal.text, fontSize = 24.sp)
}

@Composable
private fun Tile(game: Game?, focused: Boolean) {
    val scale by animateFloatAsState(if (focused) 1.14f else 0.94f, tween(180), label = "scale")
    val shape = RoundedCornerShape(22.dp)
    val tint = if (game != null) tintFor(game.title) else Pal.accent

    Box(
        Modifier
            .width(TILE_W).height(TILE_H)
            .scale(scale)
            .clip(shape)
            .border(if (focused) 4.dp else 0.dp, if (focused) Pal.accent else Color.Transparent, shape)
            .background(Brush.linearGradient(listOf(tint, tint.copy(alpha = 0.45f), Pal.panel)))
    ) {
        if (game == null) {
            // Settings tile: three sliders drawn by hand so we don't depend on an icon font.
            Canvas(Modifier.align(Alignment.Center).size(84.dp)) {
                val h = size.height / 9f
                for (i in 0..2) {
                    val y = size.height * (0.15f + i * 0.35f)
                    drawRoundRect(Color.White.copy(alpha = 0.9f), Offset(0f, y), Size(size.width, h), CornerRadius(h / 2))
                    drawCircle(Pal.bg, h * 1.4f, Offset(size.width * (0.25f + i * 0.25f), y + h / 2))
                    drawCircle(Color.White, h * 1.0f, Offset(size.width * (0.25f + i * 0.25f), y + h / 2))
                }
            }
        } else {
            val cover by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, game.coverPath) {
                value = game.coverPath?.let { p ->
                    withContext(Dispatchers.IO) {
                        // Small decode: the stick only has 1 GB of RAM.
                        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeFile(p, o)
                        var s = 1
                        while (o.outWidth / (s * 2) >= 440) s *= 2
                        BitmapFactory.decodeFile(p, BitmapFactory.Options().apply { inSampleSize = s })
                            ?.asImageBitmap()
                    }
                }
            }
            if (cover != null) {
                Image(cover!!, game.title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            } else {
                Text(
                    game.title.split(' ', '-', ':').filter { it.isNotBlank() }.take(3)
                        .joinToString("") { it.first().uppercase() },
                    color = Color.White.copy(alpha = 0.92f), fontSize = 64.sp, fontWeight = FontWeight.Black,
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        }
    }
}
