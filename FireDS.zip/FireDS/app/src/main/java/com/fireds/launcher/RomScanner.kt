package com.fireds.launcher

import android.os.Environment
import java.io.File

data class Game(
    val path: String,
    val title: String,
    val sizeMb: Long,
    val coverPath: String?
)

object RomScanner {
    private val skipDirs = setOf("Android", "LOST.DIR", "System Volume Information")

    /** Finds .nds files on internal storage and any USB drives (/storage/XXXX-XXXX). */
    fun scan(prefs: Prefs): List<Game> {
        val roots = mutableListOf<File>()
        roots += Environment.getExternalStorageDirectory()
        File("/storage").listFiles()?.forEach { f ->
            if (f.isDirectory && f.name != "self" && f.name != "emulated") roots += f
        }

        val found = LinkedHashMap<String, Game>()
        for (root in roots.distinctBy { it.absolutePath }) {
            if (!root.canRead()) continue
            root.walkTopDown()
                .maxDepth(5)
                .onEnter { dir -> !dir.name.startsWith(".") && dir.name !in skipDirs }
                .filter { it.isFile && it.extension.equals("nds", ignoreCase = true) }
                .forEach { f ->
                    found.putIfAbsent(
                        f.absolutePath,
                        Game(
                            path = f.absolutePath,
                            title = cleanTitle(f.nameWithoutExtension),
                            sizeMb = f.length() / (1024 * 1024),
                            coverPath = findCover(f, root)
                        )
                    )
                }
        }
        // Recently played first, then alphabetical.
        return found.values.sortedWith(
            compareByDescending<Game> { prefs.lastPlayed(it.path) }.thenBy { it.title.lowercase() }
        )
    }

    private fun cleanTitle(raw: String): String =
        raw.replace(Regex("\\s*[\\(\\[][^\\)\\]]*[\\)\\]]"), "").replace('_', ' ').trim().ifEmpty { raw }

    /** Optional cover art: put NAME.png/.jpg next to the ROM, or in a "covers" folder at the drive root. */
    private fun findCover(rom: File, root: File): String? {
        val base = rom.nameWithoutExtension
        for (dir in listOf(rom.parentFile, File(root, "covers"), File(root, "Covers"))) {
            for (ext in listOf("png", "jpg", "jpeg")) {
                val f = File(dir, "$base.$ext")
                if (f.isFile) return f.absolutePath
            }
        }
        return null
    }
}
