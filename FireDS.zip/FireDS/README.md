# FireDS – console-style DS launcher for Fire TV

A controller/remote-driven front end that scans for `.nds` games and launches them in
RetroArch using the DeSmuME libretro core. Nothing here emulates anything itself.

## Build the APK (on a PC or Mac)
1. Install Android Studio (free). 
2. File → Open → pick this `FireDS` folder. Let Gradle sync (needs internet, a few minutes).
3. Build → Build APK(s). Find it under `app/build/outputs/apk/debug/app-debug.apk`.

## Put it on the Fire Stick
1. On the stick: Settings → My Fire TV → Developer Options → turn on Apps from Unknown Sources (and ADB debugging).
2. Install via the Downloader app (host the APK somewhere you can reach) or `adb install app-debug.apk`.
3. Install **RetroArch** on the stick (Amazon Appstore), open it once, then in RetroArch:
   Online Updater → Core Downloader → "Nintendo DS (DeSmuME)".

## Games
Put `.nds` files on a USB drive (use a USB OTG adapter) or in Downloads. FireDS scans for them.
Optional cover art: put `GameName.png` next to the ROM, or in a `covers` folder at the drive root.
Only use ROMs you dumped from games you own.

## Controls
- Left/Right: browse   OK/A: play   Menu (☰) or Y: per-game options   Back/B: close menus
- Options: performance preset (Fast / Balanced / Quality) and screen layout, saved per game.

## Notes
- Written without being able to compile or run it, so expect to fix a typo or two on first build.
- If "RetroArch app" in Settings shows "(not found)", cycle to the other package name
  (`com.retroarch` is 32-bit, `com.retroarch.aarch64` is 64-bit).
